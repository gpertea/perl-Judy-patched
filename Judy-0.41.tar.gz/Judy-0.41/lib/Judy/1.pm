package Judy::1;
require Judy;
no warnings;
'Warning! The consumption of alcohol may cause you to think you have mystical kung-fu powers.'

